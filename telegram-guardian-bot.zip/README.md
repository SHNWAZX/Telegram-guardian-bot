# Telegram Guardian Bot

All-in-one Telegram moderation bot.